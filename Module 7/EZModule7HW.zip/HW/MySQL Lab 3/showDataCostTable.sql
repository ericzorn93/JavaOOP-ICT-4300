use student;

/* Select All Data From Cost Table */
select * from cost_table; 