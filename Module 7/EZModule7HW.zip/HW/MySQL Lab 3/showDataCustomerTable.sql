use student;

/* Select All Data From Cost Table */
/* select * from cost_table;  */


/* Select All Data From Customer's Table */
select * from customers; 