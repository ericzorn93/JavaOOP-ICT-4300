/* Eric Zorn ICT 4300: Module 2 9.9.17 */
public class Arithmetic {

      /* Write a Java program that stores the integers 62 and 99 in two variables
      and stores their sum in a variable named total. 
      Display the stored numbers and their sum.*/

      public static void main (String[] args) {
         
      //Variable Declarations
         int sixtyTwo, ninetyNine, total;
         
      //Variable Assignments
         sixtyTwo = 62;
         ninetyNine = 99;
         
      //Sum Calculation 
         total = sixtyTwo + ninetyNine;
         
       //Print Out Variable Assignments and Total  
         System.out.println("First Variable Assignment: " + sixtyTwo);

         System.out.println("Second Variable Assignment: " + ninetyNine);

         System.out.println("This is the total or sum of the two numbers: " + total);
      }
  }