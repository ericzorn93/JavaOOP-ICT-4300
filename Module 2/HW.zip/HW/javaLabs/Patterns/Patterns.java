/* Eric Zorn ICT 4300: Module 2 9.9.17 */
public class Patterns {

    public static void main(String[] args) {

       /*

            *
            ***
            *****
            *******
            *****
            ***
            *
        */

       //First Option
       System.out.println("*\n***\n*****\n*******\n*****\n***\n*");


       //Break
       System.out.println("");

       //Line Divider
       System.out.println("===============================\n\n");



       //Second Option
       System.out.println("You can also print it like this: ");
       System.out.println("*");
       System.out.println("***");
       System.out.println("*****");
       System.out.println("*******");
       System.out.println("*****");
       System.out.println("***");
       System.out.println("*");
    }

}